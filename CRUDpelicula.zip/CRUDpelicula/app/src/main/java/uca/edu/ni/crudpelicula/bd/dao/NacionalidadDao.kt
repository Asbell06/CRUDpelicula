package uca.edu.ni.crudpelicula.bd.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import uca.edu.ni.crudpelicula.bd.entidades.NacionalidadEntity

@Dao
interface NacionalidadDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(nacionalidad: NacionalidadEntity)

    @Query("SELECT * FROM TblNacionalidad")
    suspend fun getAll(): List<NacionalidadEntity>

    @Query("SELECT * FROM TblNacionalidad")
    fun getAllRealData(): LiveData<List<NacionalidadEntity>>

    @Query("SELECT * FROM TblNacionalidad WHERE idNacionalidad = :id")
    suspend fun getById(id : Int) : NacionalidadEntity

    @Update
    suspend fun update(nacionalidad: NacionalidadEntity)

    @Delete
    suspend fun delete(nacionalidad: NacionalidadEntity)

    @Query("Delete from TblNacionalidad")
    suspend fun deleteAll()
}