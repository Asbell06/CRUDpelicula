package uca.edu.ni.crudpelicula.fragments.actualizar

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import uca.edu.ni.crudpelicula.R
import uca.edu.ni.crudpelicula.bd.entidades.IdiomaEntity
import uca.edu.ni.crudpelicula.bd.viewmodels.IdiomaViewModels
import uca.edu.ni.crudpelicula.databinding.FragmentActualizarIdiomaBinding


class ActualizarIdiomaFragment : Fragment() {
    lateinit var fBinding: FragmentActualizarIdiomaBinding
    private val args by navArgs<ActualizarIdiomaFragmentArgs>()
    private lateinit var viewModel: IdiomaViewModels
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        fBinding =
            FragmentActualizarIdiomaBinding.inflate(layoutInflater)
        viewModel =
            ViewModelProvider(this).get(IdiomaViewModels::class.java)
        with(fBinding) {
            etNombreIdi.setText(args.currentIdioma.nombre)
            btnActualizarIdi.setOnClickListener {
                GuardarCambios()
            }
        }
        //Agregar menu
        setHasOptionsMenu(true)
        return fBinding.root
    }
    private fun GuardarCambios() {
        val nomb = fBinding.etNombreIdi.text.toString()

        if(nomb.isNotEmpty() && nomb.isNotEmpty())
        {
            //Crear el objeto
            val idi =
                IdiomaEntity(args.currentIdioma.idIdioma, true, nomb)
            //Actualizar
            viewModel.actualizarIdioma(idi)
            Toast.makeText(requireContext(), "Registro actualizado",
                Toast.LENGTH_LONG).show()
            findNavController().navigate(R.id.volver_lista_Idi)
        }
        else
        {
            Toast.makeText(requireContext(), "Debe rellenar todos los campos", Toast.LENGTH_LONG).show()
        }
    }
    override fun onCreateOptionsMenu(menu: Menu, inflater:
    MenuInflater) {
        inflater.inflate(R.menu.menu, menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean
    {
        if (item.itemId == R.id.delete_item) {
            eliminarClasificacion()
        }
        return super.onOptionsItemSelected(item)
    }
    private fun eliminarClasificacion() {
        val alerta = AlertDialog.Builder(requireContext())
        alerta.setPositiveButton("Si") { _, _ ->
            viewModel.eliminarIdioma(args.currentIdioma)
            Toast.makeText(
                requireContext(),
                "Registro eliminado satisfactoriamente...",
                Toast.LENGTH_LONG
            ).show()
            findNavController().navigate(R.id.volver_lista_Idi)
        }
        alerta.setNegativeButton("No") { _, _ ->
            Toast.makeText(
                requireContext(),
                "Operación cancelada...",
                Toast.LENGTH_LONG
            ).show()
        }
        alerta.setTitle("Eliminando ${args.currentIdioma.nombre}")
        alerta.setMessage("¿Esta seguro de eliminar a ${args.currentIdioma.nombre}?")
        alerta.create().show()
    }

}