package uca.edu.ni.crudpelicula.fragments.agregar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import uca.edu.ni.crudpelicula.R
import uca.edu.ni.crudpelicula.bd.entidades.ClasificacionEntity
import uca.edu.ni.crudpelicula.bd.viewmodels.ClasificacionViewModels
import uca.edu.ni.crudpelicula.databinding.FragmentAddClasificacionBinding

class NuevaClasificacionFragment : Fragment() {

    lateinit var fBinding: FragmentAddClasificacionBinding
    private lateinit var viewModel: ClasificacionViewModels
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        fBinding =
            FragmentAddClasificacionBinding.inflate(layoutInflater)
        viewModel =
            ViewModelProvider(this).get(ClasificacionViewModels::class.java)
        fBinding.btnGuardarClas.setOnClickListener {
            guardarRegistro()
        }
        return fBinding.root
    }
    private fun guardarRegistro() {
        //val baseDatos = MainBaseDatos.getDataBase(this)
        val abrev = fBinding.etAbreviacion.text.toString()
        val nomb = fBinding.etNombreClas.text.toString()

        if(abrev.isNotEmpty() && nomb.isNotEmpty())
        {
            //Crear objeto
            val clasif = ClasificacionEntity(0, abrev,true ,nomb)

            //Agregar nueva clasificación
            viewModel.agregarClasificacion(clasif)
            Toast.makeText(requireContext(), "Registro guardado",
                Toast.LENGTH_LONG).show()
             findNavController().navigate(R.id.ir_lista_clasificacion)
        }
        else
        {
            Toast.makeText(requireContext(), "Debe rellenar todos los campos", Toast.LENGTH_LONG).show()
        }


    }
}

