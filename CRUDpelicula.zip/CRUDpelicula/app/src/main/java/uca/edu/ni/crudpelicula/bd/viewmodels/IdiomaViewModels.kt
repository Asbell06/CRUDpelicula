package uca.edu.ni.crudpelicula.bd.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uca.edu.ni.crudpelicula.bd.dao.MainDataBase
import uca.edu.ni.crudpelicula.bd.entidades.IdiomaEntity
import uca.edu.ni.crudpelicula.bd.repository.IdiomaRepository

class IdiomaViewModels (application: Application): AndroidViewModel(application) {
    val lista : LiveData<List<IdiomaEntity>>
    private val repository: IdiomaRepository
    init {
        val idiomaDao =
            MainDataBase.getDataBase(application).idiomaDao()
        repository = IdiomaRepository(idiomaDao)
        lista = repository.listado
    }
    fun agregarIdioma(idioma: IdiomaEntity){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addIdioma(idioma)
        }
    }
    fun actualizarIdioma(idioma: IdiomaEntity){
        viewModelScope.launch(Dispatchers.IO){
            repository.updateIdioma(idioma)
        }
    }
    fun eliminarIdioma(idioma: IdiomaEntity){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteIdioma(idioma)
        }
    }
    fun eliminarTodo(){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAll()
        }
    }
}