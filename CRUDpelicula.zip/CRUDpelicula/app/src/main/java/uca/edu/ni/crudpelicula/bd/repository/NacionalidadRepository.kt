package uca.edu.ni.crudpelicula.bd.repository

import androidx.lifecycle.LiveData
import uca.edu.ni.crudpelicula.bd.dao.NacionalidadDao
import uca.edu.ni.crudpelicula.bd.entidades.NacionalidadEntity

class NacionalidadRepository (private val dao: NacionalidadDao) {
    val listado : LiveData<List<NacionalidadEntity>> =
        dao.getAllRealData()
    suspend fun addNacionalidad(nacionalidad: NacionalidadEntity){
        dao.insert(nacionalidad)
    }
    suspend fun updateNacionalidad(nacionalidad: NacionalidadEntity){
        dao.update(nacionalidad)
    }
    suspend fun deleteNacionalidad(nacionalidad: NacionalidadEntity){
        dao.delete(nacionalidad)
    }
    suspend fun deleteAll(){
        dao.deleteAll()
    }
}