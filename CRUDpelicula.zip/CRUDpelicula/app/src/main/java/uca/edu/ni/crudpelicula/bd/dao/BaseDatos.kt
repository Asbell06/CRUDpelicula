package uca.edu.ni.crudpelicula.bd.dao

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import uca.edu.ni.crudpelicula.bd.entidades.ClasificacionEntity
import uca.edu.ni.crudpelicula.bd.entidades.GeneroEntity
import uca.edu.ni.crudpelicula.bd.entidades.IdiomaEntity
import uca.edu.ni.crudpelicula.bd.entidades.NacionalidadEntity

interface MainDataBaseProvider {
    fun clasificacionDao(): ClasificacionDao
    fun generoDao(): GeneroDao
    fun idiomaDao(): IdiomaDao
    fun nacionalidadDao(): NacionalidadDao
}

@Database(
    entities = [ClasificacionEntity::class, GeneroEntity::class, IdiomaEntity::class, NacionalidadEntity::class], version = 4
)
abstract class MainDataBase : RoomDatabase(), MainDataBaseProvider {
    abstract override fun clasificacionDao(): ClasificacionDao
    abstract override fun generoDao(): GeneroDao
    abstract override fun idiomaDao(): IdiomaDao
    abstract override fun nacionalidadDao(): NacionalidadDao


    companion object {
        @Volatile
        private var INSTANCE: MainDataBase? = null
        fun getDataBase(context: Context): MainDataBase {
            synchronized(this) {
                var instance = INSTANCE
                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        MainDataBase::class.java,
                        "main_db"
                    ).fallbackToDestructiveMigration()
                        .build()
                    INSTANCE = instance
                }
                return instance
            }
        }
    }
}