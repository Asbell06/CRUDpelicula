package uca.edu.ni.crudpelicula.bd.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import uca.edu.ni.crudpelicula.bd.entidades.GeneroEntity
import uca.edu.ni.crudpelicula.databinding.ListaGeneroBinding
import uca.edu.ni.crudpelicula.fragments.lista.ListaGeneroFragmentDirections

class GeneroAdapter: RecyclerView.Adapter<GeneroAdapter.GeneroHolder>(){
    var listaGen:List<GeneroEntity> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GeneroHolder {
        val binding = ListaGeneroBinding.inflate(LayoutInflater.from(parent.context), parent,false)
        return GeneroHolder(binding)
    }

    override fun onBindViewHolder(holder: GeneroHolder, position: Int) : Unit =
        holder.bind(listaGen[position])

    override fun getItemCount(): Int =listaGen.size

    fun setData(gen: List<GeneroEntity>) {
        this.listaGen = gen
        notifyDataSetChanged()
    }


    inner class GeneroHolder(val binding: ListaGeneroBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(gen: GeneroEntity){
            with(binding){
                idGenero.text = gen.idGenero.toString()
                nombreGenero.text = gen.nombre

                GenFila.setOnClickListener{
                    val action= ListaGeneroFragmentDirections.modificarGenero(gen)
                    it.findNavController().navigate(action)
                }

            }
        }
    }
}