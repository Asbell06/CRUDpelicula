package uca.edu.ni.crudpelicula.bd.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.lista_idioma.view.*
import uca.edu.ni.crudpelicula.bd.entidades.IdiomaEntity
import uca.edu.ni.crudpelicula.databinding.ListaIdiomaBinding
import uca.edu.ni.crudpelicula.fragments.lista.ListaIdiomaFragmentDirections

class IdiomaAdapter: RecyclerView.Adapter<IdiomaAdapter.IdiomaHolder>(){
    var listaIdi:List<IdiomaEntity> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IdiomaAdapter.IdiomaHolder {
        val binding = ListaIdiomaBinding.inflate(LayoutInflater.from(parent.context), parent,false)
        return IdiomaHolder(binding)
    }

    override fun onBindViewHolder(holder: IdiomaHolder, position: Int) : Unit =
        holder.bind(listaIdi[position])

    override fun getItemCount(): Int =listaIdi.size

    fun setData(idi: List<IdiomaEntity>) {
        this.listaIdi = idi
        notifyDataSetChanged()
    }


    inner class IdiomaHolder(val binding: ListaIdiomaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(idi: IdiomaEntity){
            with(binding){
                idIdioma.text = idi.idIdioma.toString()
                nombreIdioma.text = idi.nombre

                IdiFila.setOnClickListener{
                    val action= ListaIdiomaFragmentDirections.modificarIdioma(idi)
                    it.findNavController().navigate(action)
                }
            }
        }
    }
}