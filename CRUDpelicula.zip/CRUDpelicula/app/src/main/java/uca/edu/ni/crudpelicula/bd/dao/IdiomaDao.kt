package uca.edu.ni.crudpelicula.bd.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import uca.edu.ni.crudpelicula.bd.entidades.IdiomaEntity

@Dao
interface IdiomaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(idioma: IdiomaEntity)

    @Query("SELECT * FROM TblIdioma")
    suspend fun getAll(): List<IdiomaEntity>

    @Query("SELECT * FROM TblIdioma")
    fun getAllRealData(): LiveData<List<IdiomaEntity>>

    @Query("SELECT * FROM TblIdioma WHERE idIdioma = :id")
    suspend fun getById(id : Int) : IdiomaEntity

    @Update
    suspend fun update(idioma: IdiomaEntity)

    @Delete
    suspend fun delete(idioma: IdiomaEntity)

    @Query("Delete from TblIdioma")
    suspend fun deleteAll()
}