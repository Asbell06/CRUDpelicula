package uca.edu.ni.crudpelicula.fragments.actualizar

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import kotlinx.android.synthetic.main.lista_genero.*
import uca.edu.ni.crudpelicula.R
import uca.edu.ni.crudpelicula.bd.entidades.GeneroEntity
import uca.edu.ni.crudpelicula.bd.viewmodels.GeneroViewModels
import uca.edu.ni.crudpelicula.databinding.FragmentActualizarGeneroBinding

class ActualizarGeneroFragment : Fragment() {
    lateinit var fBinding: FragmentActualizarGeneroBinding
    private val args by navArgs<ActualizarGeneroFragmentArgs>()
    private lateinit var viewModel: GeneroViewModels
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        fBinding =
            FragmentActualizarGeneroBinding.inflate(layoutInflater)
        viewModel =
            ViewModelProvider(this).get(GeneroViewModels::class.java)
        with(fBinding) {

            etNombreGen.setText(args.currentGenero.nombre)
            btnActualizarGen.setOnClickListener {
                GuardarCambios()
            }
        }
        //Agregar menu
        setHasOptionsMenu(true)
        return fBinding.root
    }
    private fun GuardarCambios() {
        val nomb = fBinding.etNombreGen.text.toString()

        if (nomb.isNotEmpty())
        {
            //Crear el objeto
            val gen =
                GeneroEntity(args.currentGenero.idGenero, true, nomb)
            //Actualizar
            viewModel.actualizarGenero(gen)
            Toast.makeText(requireContext(), "Registro actualizado",
                Toast.LENGTH_LONG).show()
            findNavController().navigate(R.id.volver_lista_gen)
        }
        else
        {
            Toast.makeText(requireContext(), "Debe rellenar todos los campos", Toast.LENGTH_LONG).show()
        }


    }
    override fun onCreateOptionsMenu(menu: Menu, inflater:
    MenuInflater
    ) {
        inflater.inflate(R.menu.menu, menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean
    {
        if (item.itemId == R.id.delete_item) {
            eliminarGenero()
        }
        return super.onOptionsItemSelected(item)
    }
    private fun eliminarGenero() {
        val alerta = AlertDialog.Builder(requireContext())
        alerta.setPositiveButton("Si") { _, _ ->
            viewModel.eliminarGenero(args.currentGenero)
            Toast.makeText(
                requireContext(),
                "Registro eliminado satisfactoriamente...",
                Toast.LENGTH_LONG
            ).show()
            findNavController().navigate(R.id.volver_lista_gen)
        }
        alerta.setNegativeButton("No") { _, _ ->
            Toast.makeText(
                requireContext(),
                "Operación cancelada...",
                Toast.LENGTH_LONG
            ).show()
        }
        alerta.setTitle("Eliminando ${args.currentGenero.nombre}")
        alerta.setMessage("¿Esta seguro de eliminar a ${args.currentGenero.nombre}?")
        alerta.create().show()

    }
}