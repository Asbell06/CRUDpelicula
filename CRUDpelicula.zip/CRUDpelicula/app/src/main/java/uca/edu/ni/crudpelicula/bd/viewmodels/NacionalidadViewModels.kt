package uca.edu.ni.crudpelicula.bd.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uca.edu.ni.crudpelicula.bd.dao.MainDataBase
import uca.edu.ni.crudpelicula.bd.entidades.NacionalidadEntity
import uca.edu.ni.crudpelicula.bd.repository.NacionalidadRepository

class NacionalidadViewModels (application: Application): AndroidViewModel(application) {
    val lista : LiveData<List<NacionalidadEntity>>
    private val repository: NacionalidadRepository
    init {
        val nacionalidadDao =
            MainDataBase.getDataBase(application).nacionalidadDao()
        repository = NacionalidadRepository(nacionalidadDao)
        lista = repository.listado
    }
    fun agregarNacionalidad(nacionalidad: NacionalidadEntity){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addNacionalidad(nacionalidad)
        }
    }
    fun actualizarNacionalidad(nacionalidad: NacionalidadEntity){
        viewModelScope.launch(Dispatchers.IO){
            repository.updateNacionalidad(nacionalidad)
        }
    }
    fun eliminarNacionalidad(nacionalidad: NacionalidadEntity){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteNacionalidad(nacionalidad)
        }
    }
    fun eliminarTodo(){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAll()
        }
    }
}