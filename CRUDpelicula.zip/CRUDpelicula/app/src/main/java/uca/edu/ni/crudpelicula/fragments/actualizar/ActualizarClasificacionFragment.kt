package uca.edu.ni.crudpelicula.fragments.actualizar

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import kotlinx.android.synthetic.main.fragment_add_clasificacion.*
import uca.edu.ni.crudpelicula.R
import uca.edu.ni.crudpelicula.bd.entidades.ClasificacionEntity
import uca.edu.ni.crudpelicula.bd.viewmodels.ClasificacionViewModels
import uca.edu.ni.crudpelicula.databinding.FragmentActualizarClasificacionBinding

class ActualizarClasificacionFragment : Fragment() {
    lateinit var fBinding: FragmentActualizarClasificacionBinding
    private val args by navArgs<ActualizarClasificacionFragmentArgs>()
    private lateinit var viewModel: ClasificacionViewModels

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        fBinding =
            FragmentActualizarClasificacionBinding.inflate(layoutInflater)
        viewModel =
            ViewModelProvider(this).get(ClasificacionViewModels::class.java)
        with(fBinding) {

            etAbreviacion.setText(args.currentClasificacion.abreviacion)
            etNombreClas.setText(args.currentClasificacion.nombre)
            btnActualizarClas.setOnClickListener {
                GuardarCambios()
            }

        }
        //Agregar menu
        setHasOptionsMenu(true)
        return fBinding.root
    }

    private fun GuardarCambios() {
        val abrev = fBinding.etAbreviacion.text.toString()
        val nomb = fBinding.etNombreClas.text.toString()

        if(abrev.isNotEmpty() && nomb.isNotEmpty())
        {
            //Crear el objeto
            val clasif =
                ClasificacionEntity(args.currentClasificacion.idClasificacion, abrev, true, nomb)
            //Actualizar
            viewModel.actualizarClasificacion(clasif)
            Toast.makeText(requireContext(), "Registro actualizado",
                Toast.LENGTH_LONG).show()
            findNavController().navigate(R.id.volver_lista_clas)

        }

        else
        {
            Toast.makeText(requireContext(), "Debe rellenar todos los campos", Toast.LENGTH_LONG).show()
        }


    }
    override fun onCreateOptionsMenu(menu: Menu, inflater:
    MenuInflater) {
        inflater.inflate(R.menu.menu, menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean
    {
        if (item.itemId == R.id.delete_item) {
            eliminarClasificacion()
        }
        return super.onOptionsItemSelected(item)
    }
    private fun eliminarClasificacion() {
        val alerta = AlertDialog.Builder(requireContext())
        alerta.setPositiveButton("Si") { _, _ ->
            viewModel.eliminarClasificacion(args.currentClasificacion)
            Toast.makeText(
                requireContext(),
                "Registro eliminado satisfactoriamente...",
                Toast.LENGTH_LONG
            ).show()
            findNavController().navigate(R.id.volver_lista_clas)
        }
        alerta.setNegativeButton("No") { _, _ ->
            Toast.makeText(
                requireContext(),
                "Operación cancelada...",
                Toast.LENGTH_LONG
            ).show()
        }
        alerta.setTitle("Eliminando ${args.currentClasificacion.abreviacion}")
        alerta.setMessage("¿Esta seguro de eliminar a ${args.currentClasificacion.abreviacion}?")
        alerta.create().show()
    }

}