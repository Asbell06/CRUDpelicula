package uca.edu.ni.crudpelicula.bd.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.fragment_add_nacionalidad.view.*
import uca.edu.ni.crudpelicula.bd.entidades.NacionalidadEntity
import uca.edu.ni.crudpelicula.databinding.ListaNacionalidadBinding
import uca.edu.ni.crudpelicula.fragments.lista.ListaNacionalidadFragmentDirections

class NacionalidadAdapter: RecyclerView.Adapter<NacionalidadAdapter.NacionalidadHolder>(){
    var listaNac:List<NacionalidadEntity> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NacionalidadHolder {
        val binding = ListaNacionalidadBinding.inflate(LayoutInflater.from(parent.context), parent,false)
        return NacionalidadHolder(binding)
    }

    override fun onBindViewHolder(holder: NacionalidadAdapter.NacionalidadHolder, position: Int) : Unit =
        holder.bind(listaNac[position])

    override fun getItemCount(): Int =listaNac.size

    fun setData(nac: List<NacionalidadEntity>) {
        this.listaNac = nac
        notifyDataSetChanged()
    }


    inner class NacionalidadHolder(val binding: ListaNacionalidadBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(nac: NacionalidadEntity){
            with(binding){
                idNacionalidad.text = nac.idNacionalidad.toString()
                nombreNacionalidad.text = nac.nombre

                NacFila.setOnClickListener{
                    val action= ListaNacionalidadFragmentDirections.modificarNacionalidad(nac)
                    it.findNavController().navigate(action)
                }
            }

        }
    }
}