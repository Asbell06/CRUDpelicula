package uca.edu.ni.crudpelicula.bd.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import uca.edu.ni.crudpelicula.bd.entidades.ClasificacionEntity
import uca.edu.ni.crudpelicula.databinding.ListaClasificacionBinding
import uca.edu.ni.crudpelicula.fragments.lista.ListaClasificacionFragmentDirections

class ClasificacionAdapter: RecyclerView.Adapter<ClasificacionAdapter.ClasificacionHolder>(){
    var listaClasif:List<ClasificacionEntity> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClasificacionHolder{
        val binding = ListaClasificacionBinding.inflate(LayoutInflater.from(parent.context), parent,false)
        return ClasificacionHolder(binding)
    }

    override fun onBindViewHolder(holder: ClasificacionHolder, position: Int) : Unit =
        holder.bind(listaClasif[position])

    override fun getItemCount(): Int =listaClasif.size

    fun setData(clas: List<ClasificacionEntity>) {
        this.listaClasif = clas
        notifyDataSetChanged()
    }


    inner class ClasificacionHolder(val binding: ListaClasificacionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(clas : ClasificacionEntity){
            with(binding){
                idClasificacion.text = clas.idClasificacion.toString()
                abreviatura.text = clas.abreviacion
                nombreClasificacion.text = clas.nombre

                ClasiFila.setOnClickListener{
                    val action= ListaClasificacionFragmentDirections.modificarClasificacion(clas)
                    it.findNavController().navigate(action)
                }

            }

        }
    }
}