package uca.edu.ni.crudpelicula.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import uca.edu.ni.crudpelicula.R
import uca.edu.ni.crudpelicula.databinding.FragmentSelectBinding

class BotonSelectFragment : Fragment() {

    lateinit var binding: FragmentSelectBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {

        binding = FragmentSelectBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        with(binding){

            btnClasificacion.setOnClickListener {
                it.findNavController().navigate(R.id.menu_a_lista_clasificacion)
            }

            btnGenero.setOnClickListener {
                it.findNavController().navigate(R.id.menu_a_lista_genero)
            }

            btnIdioma.setOnClickListener {
                it.findNavController().navigate(R.id.menu_a_lista_idioma)
            }

            btnNacionalidad.setOnClickListener {
                it.findNavController().navigate(R.id.menu_a_lista_nacionalidad)
            }

        }
    }
}